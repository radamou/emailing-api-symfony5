<?php declare(strict_types = 1);

namespace PHPStan\Symfony;

final class XmlContainerNotExistsException extends \InvalidArgumentException
{

}
