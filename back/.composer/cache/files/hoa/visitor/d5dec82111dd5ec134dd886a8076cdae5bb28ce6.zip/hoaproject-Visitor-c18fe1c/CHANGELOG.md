# 2.17.01.16

  * Quality: Happy new year! (Alexis von Glasow, 2017-01-09T21:37:12+01:00)
  * Documentation: New `README.md` file. (Ivan Enderlin, 2016-10-19T16:38:45+02:00)
  * Documentation: Update `support` properties. (Ivan Enderlin, 2016-10-11T08:49:14+02:00)

# 2.16.01.11

  * Quality: Drop PHP5.4. (Ivan Enderlin, 2016-01-11T09:15:27+01:00)
  * Quality: Run devtools:cs. (Ivan Enderlin, 2016-01-09T09:11:14+01:00)
  * Core: Remove `Hoa\Core`. (Ivan Enderlin, 2016-01-09T08:28:17+01:00)
  * Consistency: Use `Hoa\Consistency`. (Ivan Enderlin, 2015-12-08T22:13:46+01:00)

# 1.15.08.17

  * Add a `.gitignore` file. (Stéphane HULARD, 2015-08-03T11:50:31+02:00)

# 1.15.05.29

  * Move to PSR-1 and PSR-2. (Ivan Enderlin, 2015-05-15T10:01:52+02:00)

# 1.15.02.26

  * Add the `CHANGELOG.md` file. (Ivan Enderlin, 2015-02-26T08:33:18+01:00)
  * Happy new year! (Ivan Enderlin, 2015-01-05T14:56:34+01:00)

# 1.14.12.10

  * Move to PSR-4. (Ivan Enderlin, 2014-12-10T08:57:26+01:00)
  * Require `hoa/test`. (Alexis von Glasow, 2014-11-26T13:27:32+01:00)

# 1.14.11.15

  * Finalizing `Hoa\Visitor`! (Ivan Enderlin, 2014-11-15T22:17:25+01:00)
  * Best tests ever. (Ivan Enderlin, 2014-11-15T22:14:50+01:00)
  * Remove the unnecessary exception. (Ivan Enderlin, 2014-11-15T22:10:05+01:00)
  * Remove `from`/`import` and update to PHP5.4. (Ivan Enderlin, 2014-11-15T22:02:43+01:00)
  * Remove the visitor registry. (Ivan Enderlin, 2014-11-15T22:00:34+01:00)

# 0.14.09.23

  * Add `branch-alias`. (Stéphane PY, 2014-09-23T11:50:51+02:00)

# 0.14.09.17

  * Drop PHP5.3. (Ivan Enderlin, 2014-09-17T17:10:43+02:00)
  * Add the installation section. (Ivan Enderlin, 2014-09-17T17:10:30+02:00)

(first snapshot)
