# 1.17.01.10

  * Quality: Happy new year! (Alexis von Glasow, 2017-01-09T23:56:56+01:00)
  * Documentation: New `README.md` file. (Ivan Enderlin, 2016-10-22T17:36:15+02:00)
  * Documentation: Update `support` properties. (Ivan Enderlin, 2016-10-11T11:41:21+02:00)

# 1.16.03.15

  * Parameter: Fix API documentation, namings… (Metalaka, 2016-01-16T08:02:35+01:00)

# 1.16.01.14

  * Quality: Drop PHP5.4. (Ivan Enderlin, 2016-01-11T09:15:27+01:00)
  * Quality: Run devtools:cs. (Ivan Enderlin, 2016-01-09T09:12:47+01:00)
  * Core: Remove `Hoa\Core`. (Ivan Enderlin, 2016-01-09T08:34:03+01:00)
  * Consistency: Remove the flexible entity. (Ivan Enderlin, 2016-01-09T07:47:57+01:00)
  * Split from `Hoa\Core`. (Ivan Enderlin, 2016-01-09T07:45:36+01:00)

(first snapshot)
