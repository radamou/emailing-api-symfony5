<?php

declare(strict_types=1);

namespace JMS\Serializer\Type\Exception;

final class InvalidNode extends \LogicException implements Exception
{
}
