<?php

declare(strict_types=1);

namespace JMS\Serializer\Type\Exception;

use JMS\Serializer\Exception\Exception as BaseException;

interface Exception extends BaseException
{
}
