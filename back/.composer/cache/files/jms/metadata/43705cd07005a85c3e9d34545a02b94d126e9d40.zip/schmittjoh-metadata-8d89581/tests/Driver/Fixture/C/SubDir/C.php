<?php

declare(strict_types=1);

namespace Metadata\Tests\Driver\Fixture\C\SubDir;

class C
{
}
