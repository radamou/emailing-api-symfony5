<?php

declare(strict_types=1);

namespace Metadata\Tests\Fixtures\ComplexHierarchy;

interface InterfaceA
{
}
