---
name: ⛔ Documentation Issue
about: See https://github.com/symfony/symfony-docs/issues for documentation issues

---

Symfony Documentation has its own dedicated repository. Please open your
documentation-related issue at https://github.com/symfony/symfony-docs/issues

Thanks!
